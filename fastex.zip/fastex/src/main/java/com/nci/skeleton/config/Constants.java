package com.nci.skeleton.config;

public class Constants {

    public static final String STATUS_ACTIVE="A";
    public static final String STATUS_INACTIVE="I";
}
