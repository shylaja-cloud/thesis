package com.nci.skeleton.security;

public enum Role {
    USER,
    ADMIN
}
