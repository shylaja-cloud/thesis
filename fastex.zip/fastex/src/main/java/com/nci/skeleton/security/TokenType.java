package com.nci.skeleton.security;

public enum TokenType {
    BEARER
}
